import React from 'react'

type Props = {}

export default function page({}: Props) {
  return (
    <div>page</div>
  )
}
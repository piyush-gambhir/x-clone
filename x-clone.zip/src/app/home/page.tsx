import React from "react";

type Props = {};

export default function page({}: Props) {
  return <div>Home Page</div>;
}
